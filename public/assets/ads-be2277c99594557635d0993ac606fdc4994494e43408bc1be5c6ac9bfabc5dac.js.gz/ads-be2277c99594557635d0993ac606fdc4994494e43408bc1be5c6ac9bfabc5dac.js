var canRunAds = true;
